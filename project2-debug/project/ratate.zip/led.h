#ifndef _LED_
#define _LED_

void led_init(void);
void led_on(void);
void led_off(void);



#endif