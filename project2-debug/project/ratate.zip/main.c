#include "stm32f10x.h"
#include "led.h"
#include "myusart.h"
#include "pwm.h"
#include "pwm9.h"
#include "pwm10.h"
#include "pwm11.h"
#include "pwm4.h"
#include "pwm_angle.h"
#include "ztb.h"
int m=15;

//��ʱ
void delay (int n)
{
	int i;
	while(n--)
		for(i=0;i<1000;i++);
}

//���3
void pwm10_angle(int i)
{

	int n=i+m;
	int j;
	if(i>=0)
	{
	
	for(j=m;j<n+1;j++)
	{
		TIM_SetCompare2(TIM4,j);
		delay(1000);
		m=j;
	}

	}
	else 
		{
		for(j=m;j>n-1;j--)
		{
			TIM_SetCompare2(TIM4,j);
			delay(1000);
			m=j;
		}
	
		}
	
}


//�����
void pwm11_angle(int i)
{

	int n=i+m;
	int j;
	if(i>=0)
	{
	
	for(j=m;j<n+1;j++)
	{
		TIM_SetCompare1(TIM4,j);
		delay(1000);
		m=j;
	}

	}
	else 
		{
		for(j=m;j>n-1;j--)
		{
			TIM_SetCompare1(TIM4,j);
			delay(1000);
			m=j;
		}
	
		}
	
}


//�����
void pwm4_angle(int i)
{

	int n=i+m;
	int j;
	if(i>=0)
	{
	
	for(j=m;j<n+1;j++)
	{
		TIM_SetCompare4(TIM3,j);
		delay(1000);
		m=j;
	}

	}
	else 
		{
		for(j=m;j>n-1;j--)
		{
			TIM_SetCompare4(TIM3,j);
			delay(1000);
			m=j;
		}
	
		}
	
}

//A
void zta1(void)
{
		TIM_SetCompare3(TIM3,20);
		delay(100);
}
void zta2(void)
{
		TIM_SetCompare3(TIM3,25);
		delay(100);
}




//B
void ztb(void)
{
	
	for(int j=15;j<26;j++)
	{
		TIM_SetCompare2(TIM4,j);
		delay(150);
		TIM_SetCompare1(TIM4,j);
		delay(150);
		TIM_SetCompare4(TIM3,j);
		delay(150);
		
  }	
}

//C
void ztc(void)
{
	for(int j=25;j>14;j--)
	{
		TIM_SetCompare2(TIM4,j);
		delay(150);
		TIM_SetCompare1(TIM4,j);
		delay(150);
		TIM_SetCompare4(TIM3,j);
		delay(150);
  }	
}
	

//������
int main()
{
	char i;
	
	led_init();
	delay(5000);
	pwm_init();
	delay(5000);
	pwm9_init();
	delay(5000);
	pwm10_init();
	delay(5000);
	pwm11_init();
	delay(5000);
	pwm4_init();
	delay(5000);
	pwm5_init();
	delay(5000);
	
	//pwm_angle(5);//���1
	//pwm9_angle(10);//���2

	//A
	
	
	//ztb();
	//B
		
	
	//for(int j=15;j<26;j++)
	//{
	//	TIM_SetCompare1(TIM4,j);
	//	TIM_SetCompare4(TIM3,j);
	//	delay(1000);
//	}	
	
	//pwm10_angle(10);//���3
	
	//B
	//pwm10_angle(-5);//���3
	//pwm11_angle(10);//���4
	//pwm4_angle(-8);//���5
	
		//TIM_SetCompare4(TIM4,-5);//���1
		//delay(10000);
		//TIM_SetCompare3(TIM4,10);//���2
		//delay(1000);
		
		//A
		//TIM_SetCompare2(TIM4,10);//���3
		//delay(5000);
		
		//B
		//TIM_SetCompare2(TIM4,0);//���3
		//TIM_SetCompare1(TIM4,10);//���4
		//TIM_SetCompare4(TIM3,20);//���5
		//delay(5000);
		
		//C
		//TIM_SetCompare2(TIM4,20);//���3
		//TIM_SetCompare1(TIM4,20);//���4
		//TIM_SetCompare4(TIM3,5);//���5
		//delay(5000);
		
	
		//TIM_SetCompare3(TIM3,10);//���6
		//delay(5000);
		
		//myuart_init();
  while(1)
	{
		zta1();
		
		ztb();
		ztc();
		led_on();
		delay(1000);
		led_off();
		delay(1000);
		
		
		zta2();
	
		ztb();
		ztc();
		led_on();
		delay(1000);
		led_off();
		delay(1000);
		
		
		//c = myuart_receive();
		//myuart_send(c);
  }
	return 0;
}

