#ifndef _MY_UART_
#define _MY_UART_

void myuart_init(void);
void myuart_send(char c);
char myuart_receive(void);


#endif