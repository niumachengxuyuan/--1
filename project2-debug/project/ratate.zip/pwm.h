#ifndef _PWM_
#define _PWM_

void pwm_init(void);


#endif