#ifndef _PWM_
#define _PWM_

void pwm4_init(void);


#endif