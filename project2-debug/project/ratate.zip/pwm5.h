#ifndef _PWM_
#define _PWM_

void pwm5_init(void);


#endif