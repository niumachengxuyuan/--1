#ifndef _PWM_
#define _PWM_

void pwm_angle(int i);
void pwm9_angle(int i);
void pwm10_angle(int i);
void pwm11_angle(int i);
void pwm4_angle(int i);
void pwm5_angle(int i);

#endif